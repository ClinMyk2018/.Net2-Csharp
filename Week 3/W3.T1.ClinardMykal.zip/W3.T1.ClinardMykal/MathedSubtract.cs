﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W3.T1.ClinardMykal
{
    internal class MathedSubtract : Mathed
    {
        public override double DoMathed(double number1, double number2)
        {
            return (number1 - number2);
        }

    }
}
