﻿namespace W2.T3.ClinardMykal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FNameLabel = new System.Windows.Forms.Label();
            this.LNameLabel = new System.Windows.Forms.Label();
            this.AgeLabel = new System.Windows.Forms.Label();
            this.dOBLabel = new System.Windows.Forms.Label();
            this.socialSecNumLabel = new System.Windows.Forms.Label();
            this.PN1Label = new System.Windows.Forms.Label();
            this.PN2Label = new System.Windows.Forms.Label();
            this.Ad1Label = new System.Windows.Forms.Label();
            this.Ad2Label = new System.Windows.Forms.Label();
            this.FNTextBox = new System.Windows.Forms.TextBox();
            this.LNTextBox = new System.Windows.Forms.TextBox();
            this.DOBTextBox = new System.Windows.Forms.TextBox();
            this.SSNTextBox = new System.Windows.Forms.TextBox();
            this.PN1TextBox = new System.Windows.Forms.TextBox();
            this.PN2TextBox = new System.Windows.Forms.TextBox();
            this.AD1TextBox = new System.Windows.Forms.TextBox();
            this.AD2TextBox = new System.Windows.Forms.TextBox();
            this.CITYTextBox = new System.Windows.Forms.TextBox();
            this.CityLabel = new System.Windows.Forms.Label();
            this.StateLabel = new System.Windows.Forms.Label();
            this.ZipLabel = new System.Windows.Forms.Label();
            this.STATETextBox = new System.Windows.Forms.TextBox();
            this.ZIPTextBox = new System.Windows.Forms.TextBox();
            this.AGETextBox = new System.Windows.Forms.TextBox();
            this.addStudentBttn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.First_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Last_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dltstdt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // FNameLabel
            // 
            this.FNameLabel.AutoSize = true;
            this.FNameLabel.Location = new System.Drawing.Point(12, 13);
            this.FNameLabel.Name = "FNameLabel";
            this.FNameLabel.Size = new System.Drawing.Size(57, 13);
            this.FNameLabel.TabIndex = 0;
            this.FNameLabel.Text = "First Name";
            // 
            // LNameLabel
            // 
            this.LNameLabel.AutoSize = true;
            this.LNameLabel.Location = new System.Drawing.Point(97, 13);
            this.LNameLabel.Name = "LNameLabel";
            this.LNameLabel.Size = new System.Drawing.Size(58, 13);
            this.LNameLabel.TabIndex = 1;
            this.LNameLabel.Text = "Last Name";
            // 
            // AgeLabel
            // 
            this.AgeLabel.AutoSize = true;
            this.AgeLabel.Location = new System.Drawing.Point(194, 13);
            this.AgeLabel.Name = "AgeLabel";
            this.AgeLabel.Size = new System.Drawing.Size(26, 13);
            this.AgeLabel.TabIndex = 2;
            this.AgeLabel.Text = "Age";
            // 
            // dOBLabel
            // 
            this.dOBLabel.AutoSize = true;
            this.dOBLabel.Location = new System.Drawing.Point(263, 13);
            this.dOBLabel.Name = "dOBLabel";
            this.dOBLabel.Size = new System.Drawing.Size(30, 13);
            this.dOBLabel.TabIndex = 3;
            this.dOBLabel.Text = "DOB";
            // 
            // socialSecNumLabel
            // 
            this.socialSecNumLabel.AutoSize = true;
            this.socialSecNumLabel.Location = new System.Drawing.Point(350, 13);
            this.socialSecNumLabel.Name = "socialSecNumLabel";
            this.socialSecNumLabel.Size = new System.Drawing.Size(29, 13);
            this.socialSecNumLabel.TabIndex = 4;
            this.socialSecNumLabel.Text = "SSN";
            // 
            // PN1Label
            // 
            this.PN1Label.AutoSize = true;
            this.PN1Label.Location = new System.Drawing.Point(415, 13);
            this.PN1Label.Name = "PN1Label";
            this.PN1Label.Size = new System.Drawing.Size(87, 13);
            this.PN1Label.TabIndex = 5;
            this.PN1Label.Text = "Phone Number 1";
            // 
            // PN2Label
            // 
            this.PN2Label.AutoSize = true;
            this.PN2Label.Location = new System.Drawing.Point(527, 13);
            this.PN2Label.Name = "PN2Label";
            this.PN2Label.Size = new System.Drawing.Size(87, 13);
            this.PN2Label.TabIndex = 6;
            this.PN2Label.Text = "Phone Number 2";
            // 
            // Ad1Label
            // 
            this.Ad1Label.AutoSize = true;
            this.Ad1Label.Location = new System.Drawing.Point(54, 61);
            this.Ad1Label.Name = "Ad1Label";
            this.Ad1Label.Size = new System.Drawing.Size(54, 13);
            this.Ad1Label.TabIndex = 7;
            this.Ad1Label.Text = "Address 1";
            // 
            // Ad2Label
            // 
            this.Ad2Label.AutoSize = true;
            this.Ad2Label.Location = new System.Drawing.Point(200, 61);
            this.Ad2Label.Name = "Ad2Label";
            this.Ad2Label.Size = new System.Drawing.Size(54, 13);
            this.Ad2Label.TabIndex = 8;
            this.Ad2Label.Text = "Address 2";
            // 
            // FNTextBox
            // 
            this.FNTextBox.Location = new System.Drawing.Point(12, 29);
            this.FNTextBox.Name = "FNTextBox";
            this.FNTextBox.Size = new System.Drawing.Size(70, 20);
            this.FNTextBox.TabIndex = 9;
            // 
            // LNTextBox
            // 
            this.LNTextBox.Location = new System.Drawing.Point(100, 29);
            this.LNTextBox.Name = "LNTextBox";
            this.LNTextBox.Size = new System.Drawing.Size(70, 20);
            this.LNTextBox.TabIndex = 10;
            // 
            // DOBTextBox
            // 
            this.DOBTextBox.Location = new System.Drawing.Point(244, 29);
            this.DOBTextBox.Name = "DOBTextBox";
            this.DOBTextBox.Size = new System.Drawing.Size(70, 20);
            this.DOBTextBox.TabIndex = 11;
            // 
            // SSNTextBox
            // 
            this.SSNTextBox.Location = new System.Drawing.Point(332, 29);
            this.SSNTextBox.Name = "SSNTextBox";
            this.SSNTextBox.Size = new System.Drawing.Size(70, 20);
            this.SSNTextBox.TabIndex = 12;
            // 
            // PN1TextBox
            // 
            this.PN1TextBox.Location = new System.Drawing.Point(408, 29);
            this.PN1TextBox.Name = "PN1TextBox";
            this.PN1TextBox.Size = new System.Drawing.Size(101, 20);
            this.PN1TextBox.TabIndex = 13;
            // 
            // PN2TextBox
            // 
            this.PN2TextBox.Location = new System.Drawing.Point(521, 29);
            this.PN2TextBox.Name = "PN2TextBox";
            this.PN2TextBox.Size = new System.Drawing.Size(100, 20);
            this.PN2TextBox.TabIndex = 14;
            // 
            // AD1TextBox
            // 
            this.AD1TextBox.Location = new System.Drawing.Point(12, 77);
            this.AD1TextBox.Name = "AD1TextBox";
            this.AD1TextBox.Size = new System.Drawing.Size(143, 20);
            this.AD1TextBox.TabIndex = 15;
            // 
            // AD2TextBox
            // 
            this.AD2TextBox.Location = new System.Drawing.Point(169, 77);
            this.AD2TextBox.Name = "AD2TextBox";
            this.AD2TextBox.Size = new System.Drawing.Size(113, 20);
            this.AD2TextBox.TabIndex = 16;
            // 
            // CITYTextBox
            // 
            this.CITYTextBox.Location = new System.Drawing.Point(299, 77);
            this.CITYTextBox.Name = "CITYTextBox";
            this.CITYTextBox.Size = new System.Drawing.Size(70, 20);
            this.CITYTextBox.TabIndex = 17;
            // 
            // CityLabel
            // 
            this.CityLabel.AutoSize = true;
            this.CityLabel.Location = new System.Drawing.Point(321, 61);
            this.CityLabel.Name = "CityLabel";
            this.CityLabel.Size = new System.Drawing.Size(24, 13);
            this.CityLabel.TabIndex = 18;
            this.CityLabel.Text = "City";
            // 
            // StateLabel
            // 
            this.StateLabel.AutoSize = true;
            this.StateLabel.Location = new System.Drawing.Point(407, 61);
            this.StateLabel.Name = "StateLabel";
            this.StateLabel.Size = new System.Drawing.Size(32, 13);
            this.StateLabel.TabIndex = 19;
            this.StateLabel.Text = "State";
            // 
            // ZipLabel
            // 
            this.ZipLabel.AutoSize = true;
            this.ZipLabel.Location = new System.Drawing.Point(497, 61);
            this.ZipLabel.Name = "ZipLabel";
            this.ZipLabel.Size = new System.Drawing.Size(22, 13);
            this.ZipLabel.TabIndex = 20;
            this.ZipLabel.Text = "Zip";
            // 
            // STATETextBox
            // 
            this.STATETextBox.Location = new System.Drawing.Point(387, 77);
            this.STATETextBox.Name = "STATETextBox";
            this.STATETextBox.Size = new System.Drawing.Size(70, 20);
            this.STATETextBox.TabIndex = 21;
            // 
            // ZIPTextBox
            // 
            this.ZIPTextBox.Location = new System.Drawing.Point(473, 77);
            this.ZIPTextBox.Name = "ZIPTextBox";
            this.ZIPTextBox.Size = new System.Drawing.Size(70, 20);
            this.ZIPTextBox.TabIndex = 22;
            // 
            // AGETextBox
            // 
            this.AGETextBox.Location = new System.Drawing.Point(185, 29);
            this.AGETextBox.Name = "AGETextBox";
            this.AGETextBox.Size = new System.Drawing.Size(44, 20);
            this.AGETextBox.TabIndex = 23;
            // 
            // addStudentBttn
            // 
            this.addStudentBttn.Location = new System.Drawing.Point(270, 113);
            this.addStudentBttn.Name = "addStudentBttn";
            this.addStudentBttn.Size = new System.Drawing.Size(75, 23);
            this.addStudentBttn.TabIndex = 24;
            this.addStudentBttn.Text = "Add Student";
            this.addStudentBttn.UseVisualStyleBackColor = true;
            this.addStudentBttn.Click += new System.EventHandler(this.addStudentBttn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.First_Name,
            this.Last_Name,
            this.Age});
            this.dataGridView1.Location = new System.Drawing.Point(100, 142);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(445, 150);
            this.dataGridView1.TabIndex = 25;
            // 
            // First_Name
            // 
            this.First_Name.HeaderText = "First Name";
            this.First_Name.Name = "First_Name";
            // 
            // Last_Name
            // 
            this.Last_Name.HeaderText = "Last Name";
            this.Last_Name.Name = "Last_Name";
            // 
            // Age
            // 
            this.Age.HeaderText = "Age";
            this.Age.Name = "Age";
            // 
            // dltstdt
            // 
            this.dltstdt.Location = new System.Drawing.Point(270, 298);
            this.dltstdt.Name = "dltstdt";
            this.dltstdt.Size = new System.Drawing.Size(75, 23);
            this.dltstdt.TabIndex = 26;
            this.dltstdt.Text = "Delete";
            this.dltstdt.UseVisualStyleBackColor = true;
            this.dltstdt.Click += new System.EventHandler(this.dltstdt_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 450);
            this.Controls.Add(this.dltstdt);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.addStudentBttn);
            this.Controls.Add(this.AGETextBox);
            this.Controls.Add(this.ZIPTextBox);
            this.Controls.Add(this.STATETextBox);
            this.Controls.Add(this.ZipLabel);
            this.Controls.Add(this.StateLabel);
            this.Controls.Add(this.CityLabel);
            this.Controls.Add(this.CITYTextBox);
            this.Controls.Add(this.AD2TextBox);
            this.Controls.Add(this.AD1TextBox);
            this.Controls.Add(this.PN2TextBox);
            this.Controls.Add(this.PN1TextBox);
            this.Controls.Add(this.SSNTextBox);
            this.Controls.Add(this.DOBTextBox);
            this.Controls.Add(this.LNTextBox);
            this.Controls.Add(this.FNTextBox);
            this.Controls.Add(this.Ad2Label);
            this.Controls.Add(this.Ad1Label);
            this.Controls.Add(this.PN2Label);
            this.Controls.Add(this.PN1Label);
            this.Controls.Add(this.socialSecNumLabel);
            this.Controls.Add(this.dOBLabel);
            this.Controls.Add(this.AgeLabel);
            this.Controls.Add(this.LNameLabel);
            this.Controls.Add(this.FNameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FNameLabel;
        private System.Windows.Forms.Label LNameLabel;
        private System.Windows.Forms.Label AgeLabel;
        private System.Windows.Forms.Label dOBLabel;
        private System.Windows.Forms.Label socialSecNumLabel;
        private System.Windows.Forms.Label PN1Label;
        private System.Windows.Forms.Label PN2Label;
        private System.Windows.Forms.Label Ad1Label;
        private System.Windows.Forms.Label Ad2Label;
        private System.Windows.Forms.TextBox FNTextBox;
        private System.Windows.Forms.TextBox LNTextBox;
        private System.Windows.Forms.TextBox DOBTextBox;
        private System.Windows.Forms.TextBox SSNTextBox;
        private System.Windows.Forms.TextBox PN1TextBox;
        private System.Windows.Forms.TextBox PN2TextBox;
        private System.Windows.Forms.TextBox AD1TextBox;
        private System.Windows.Forms.TextBox AD2TextBox;
        private System.Windows.Forms.TextBox CITYTextBox;
        private System.Windows.Forms.Label CityLabel;
        private System.Windows.Forms.Label StateLabel;
        private System.Windows.Forms.Label ZipLabel;
        private System.Windows.Forms.TextBox STATETextBox;
        private System.Windows.Forms.TextBox ZIPTextBox;
        private System.Windows.Forms.TextBox AGETextBox;
        private System.Windows.Forms.Button addStudentBttn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn First_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Last_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Age;
        private System.Windows.Forms.Button dltstdt;
    }
}

